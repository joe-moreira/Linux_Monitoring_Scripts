#!/bin/sh
#
# Funciones para el manejo de horas y fechas
#

# Funcion que devuelve el juliano de una fecha en formato dia mes anio
jd() {
   DIA=$1
   MES=$2
   ANO=$3

   # a = (14-month)/12
   # y = year+4800-a
   # m = month + 12*a - 3

   # JD = day + (153*m+2)/5 + y*365 + y/4 - y/100 + y/400 - 32045


   let "A=( 14 - $MES ) / 12"
   let "Y=$ANO + 4800 - $A"
   let "M=$MES + (12 * $A) - 3"

   let "JD=$DIA + (((153 * $M) + 2) / 5) + ($Y * 365) + ($Y / 4) - ($Y / 100) + ($Y / 400) - 32045"
   echo  $JD 
}

# Devuelve el dia de una fecha en formato añsdia
dia() {
   RETURN=`echo $1 | cut -c7-8`
   echo $RETURN
}

# Devuelve el mes de una fecha en formato añsdia
mes() {
   RETURN=`echo $1 | cut -c5-6`
   echo $RETURN
}

# Devuelve el añe una fecha en formato añsdia
ano() {
   RETURN=`echo $1 | cut -c1-4`
   echo $RETURN
}

# Devuelve la hora de una hora en formato hh:mi:ss
horas() {
   RETURN=`echo $1 | cut -c1-2`
   echo $RETURN | sed "s/^0//g"
}

# Devuelve los minutos de una hora en formato hh:mi:ss
minutos() {
   RETURN=`echo $1 | cut -c4-5`
   echo $RETURN | sed "s/^0//g"
}

# Devuelve los segundos de una hora en formato hh:mi:ss
segundos() {
   RETURN=`echo $1 | cut -c7-8`
   echo $RETURN | sed "s/^0//g"
}


# Devuelve la diferencia entre dos horas en segundos. Tiene 2 parametros en el formato hh:mi:ss
resto_horas() {
   H1=`horas $1`
   H2=`horas $2`
   M1=`minutos $1`
   M2=`minutos $2`
   S1=`segundos $1`
   S2=`segundos $2`
   SEGS1=$(($H1*60*60 + $M1*60 + $S1))
   SEGS2=$(($H2*60*60 + $M2*60 + $S2))
   RETURN=$(($SEGS1 - $SEGS2))
   
   echo $RETURN
}



