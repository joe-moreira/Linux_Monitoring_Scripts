# Know-How
# Este script reporta informacion de monitoreo para conocer el estado del servidor Linux
# Utiliza primitivas del KH-CMR, propiedad de Know-How
# 

. /operaciones/linux/khcmr/scripts/funcs.sh
. /operaciones/linux/khcmr/scripts/khlnxenv.sh /operaciones/linux/khcmr/conf/areslnx.conf

EQUIPO=`hostname`
FECHA=`date +"%Y-%m-%d %H:%M:%SS"`

echo " **** Chequeo Linux de $EQUIPO ($FECHA) ****"
echo " "

echo "Uptime"
echo "------"
uptime
echo " "
echo "Espacios fs"
echo "-----------"
df -h
echo " "
echo "Uso de memoria"
echo "--------------"
free
echo " "
echo "Log de errores"
echo "-------------"
tail -50 /var/log/messages
echo " "
echo "Usuarios logueados"
echo "------------------"
echo "- w"
w
echo " "
echo "- who"
who
echo " "
echo "Last"
echo "----"
last | head -10
echo " "
echo "Estado de volume groups"
echo "-----------------------"
echo "- vgscan"
/sbin/vgscan
echo " "
echo "- vgdisplay"
/usr/sbin/vgdisplay -v
echo " " 
echo "Volumenes fisicos"
echo "-----------------"
/sbin/fdisk -l
echo " "
echo "iostat 2 5"
echo "----------"
iostat 2 5
echo " "
echo "vmstat 2 5"
echo "----------"
vmstat 2 5
echo " "
echo "Consola de KH-CMR"
echo "-----------------"
tail -40 $CONSOLA
echo " "
#echo "Log de respaldo ...."
#echo "--------------------"
#LOG=/xxx/yyy/logs/dump_all.log.history
##taillog
#tail $LOG
#echo " "






