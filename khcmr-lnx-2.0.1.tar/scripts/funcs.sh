################################################################
## Inicio script.sh
##
## Pequeñescripció# Autor: Know-How
## Fecha:
################################################################
## Modificaciones
####
## Autor:
## Fecha:
## Descr:
####
################################################################
#! /bin/sh

VERSION="0.01b"

# Cargo configuraciones iniciales

# Variables

# Cuerpo

# Esta funcion ejecuta tareas previas a la ejecucion del scrtip
pre_exec() {

test ! -z "${PRE_EXEC_FILE}" && . ${PRE_EXEC_FILE}
return $?

}

# Esta funcion ejecuta tareas posteriores a la ejecucion del scrtip
post_exec() {

test ! -z "${POST_EXEC_FILE}" && . ${POST_EXEC_FILE}
return $?

}
# Escribe en el log de errores
write_error_log() {
echo AVISO: `date +%d"/"%b"/"%Y" - "%H:%M:%S` : $1 >> ${LOG}
echo AVISO: `date +%d"/"%b"/"%Y" - "%H:%M:%S` : $1
}


# Escribe en el log de actividad
write_active_log() {
echo $1 >> ${LOG}
echo $1
}

header() {
write_active_log "---------======== Comienzo ========---------"
write_active_log "Script: ${SCRIPT_NAME}"
write_active_log "Fecha y Hora de Inicio:`date` "
}

# Cierre del script
footer() {
write_active_log "Fecha y Hora de Fin:`date`"
write_active_log "Script: ${SCRIPT_NAME}"
#chmod 666 ${LOG}
write_active_log "---------========   Fin    ========---------"
}

ck_existe_lock() {
RESULT=0
for i in `echo ${LOCK_FILE}`;do
    test ! -f ${i}
    RESULT=$(( ${RESULT} + $? ))
done

return ${RESULT}
}

lock() {

RESULT=0
for i in `echo ${LOCK_FILE}`;do
    touch ${i} >> ${LOG} 2>> ${LOG}
    RESULT=$(( ${RESULT} + $? ))
done


return ${RESULT}
}

unlock() {

RESULT=0
for i in `echo ${LOCK_FILE}`;do
    rm -f ${i} >> ${LOG} 2>> ${LOG}
    RESULT=$(( ${RESULT} + $? ))
done

return ${RESULT}
}



write_to_smtp() {
                 sleep 4
                 echo "HELO ${MAIL_SERVER}"

                 sleep 3
                 echo "MAIL FROM: ${MAIL_FROM}"

                 sleep 3
                 for i in `echo ${MAIL_ADDRESS}`;do
                 echo "RCPT TO: ${i}"
                 sleep 1
                 done
                 sleep 3
                 echo "DATA"

                 sleep 3
                 echo "From:  ${MAIL_FROM} "

                 sleep 3
                 echo "To:  ${MAIL_FROM} "


                 sleep 3
                 echo "Subject: ${SUBJECT} "

                 sleep 3
                 cat ${MAIL_FILE}

                 sleep 3
                 echo -e ".\n"

                 sleep 1
                 echo "quit"

}


sendmail(){

if [ ! -z "${MAIL_SERVER}" ] && [ ! -z "${MAIL_ADDRESS}" ] && [ ! -z "${SUBJECT}" ] ; then
   echo "Armo el archivo de mail" >> ${LOG}
   if [ ! -z "${INCLUDE_MAIL_FILE}" ]; then
      echo "Como tiene un archivo ${INCLUDE_MAIL_FILE} para incluir lo adjunto al mail" >> ${LOG}
      cat ${INCLUDE_MAIL_FILE} >> ${MAIL_FILE}
   fi
   #echo "." >> ${MAIL_FILE}
   echo "Ahora envio el mail" >> ${LOG}
   write_to_smtp | telnet ${MAIL_SERVER} 25 >> ${LOG} 2>> ${LOG}
fi

}

taillog(){
desde=`grep -n "======== Comienzo ========" ${LOG} | tail -1| cut -f1 -d:`
lineas=`wc -l ${LOG} | awk   '{ print $1 }'`
((cuantas = $lineas - $desde +1 ))
tail -$cuantas ${LOG} 
}

#### Fin de funcs.sh



