cd /operaciones/linux/khcmr/scripts
EQUIPO=`hostname`
FECHA_SUBJECT_INI=`date +"%Y-%m-%d %H:%M:%S"`
rm -f ../logs/linux_daycheck-${EQUIPO}-$$.log
. ./linux_daycheck.sh >> ../logs/linux_daycheck-${EQUIPO}-$$.log 2>> ../logs/linux_daycheck-${EQUIPO}-$$.log
FECHA_SUBJECT_FIN=`date +"%Y-%m-%d %H:%M:%S"`
KHMAIL_SUBJECT="${KHMAIL_SUBJECT_INFO_HEAD};linux_daycheck.sh;${FECHA_SUBJECT_INI};${FECHA_SUBJECT_FIN};OK"
KHMAIL_BODY=../logs/linux_daycheck-${EQUIPO}-$$.log
kh_send_mail

rm ../logs/linux_daycheck-${EQUIPO}-$$.log

# Si tengo mas linux_daycheck.sh, repito abajo ejecuciones analogas a las anteriores




