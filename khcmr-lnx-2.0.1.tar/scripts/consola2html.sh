# consola2html.sh
# Genera a partir del archivo de consola del KH-CMR collect, un archivo html para visualizar el browser
# Ejecucion :  consola2html.sh <archorigen> <lineas> <archdestino>
#              donde lineas es un entero que indica la cantidad de lineas a tener en cuenta para generar el archivo (se
#              tomaran en cuenta las ultimas lineas)

consola2html() {
echo "<HTML>"
echo "<HEAD>"
echo "<META http-equiv=\"refresh\" content=\"60\">"
echo "<LINK rel=\"stylesheet\" type=\"text/css\" href=\"khind.css\">"
echo "</HEAD>"
echo "<BODY>"

# despliego hora del refresh
echo "<script language=\"javascript\">"
echo "var now = new Date();"
echo "var hour        = now.getHours();"
echo "var minute      = now.getMinutes();"
echo "var seconds = now.getSeconds();"
echo "if (hour   < 10) { hour   = \"0\" + hour;   }"
echo "if (minute < 10) { minute = \"0\" + minute; }"
echo "if (seconds < 10) { seconds = \"0\" + seconds; } "
echo "document.write('<table width=100%><tr><td width=100%>&nbsp;</td><td align=left class=hora width=40px>' + hour + ':' +  minute + ':' + seconds + '</td></tr></table>');"
echo "</script>"


echo "<TABLE WIDTH=100%>"
# Cabezal
echo "<TR><TD ALIGN=\"LEFT\" CLASS=\"titfrm1\">" Fecha "</TD><TD ALIGN=\"LEFT\" CLASS=\"titfrm1\">" Hora "</TD><TD ALIGN=\"LEFT\" CLASS=\"titfrm1\">" Host "</TD><TD ALIGN=\"LEFT\" CLASS=\"titfrm1\">" Indicador "</TD><TD ALIGN=\"LEFT\" CLASS=\"titfrm1\">" Objeto "</TD><TD ALIGN=\"LEFT\" CLASS=\"titfrm1\">" Valor "</TD><TD ALIGN=\"LEFT\" CLASS=\"titfrm1\">" Observaciones "</TD></TR>"
# Lineas transformadas a html
dia_ant="  "
tail -$2 $1 | while read linea; do
# echo $linea | awk '{ print  $1 " " $2 " " $3 " " $4 " " $5 " " $6 }'
 # si hay cambio de dia, agrego linea de separacion
 dia=`echo $linea | cut -c9-10`
 if [ "$dia" != "$dia_ant" ]; then
     a=1
#     echo "<TR><TD ALIGN=\"LEFT\" CLASS=\"resultado\"><HR></TD>"
     echo "<TR><TD ALIGN=\"LEFT\" CLASS=\"resultado\"><HR></TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\"><HR></TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\"><HR></TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\"><HR></TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\"><HR></TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\"><HR></TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\"><HR></TD>"
#     echo "<TR><TD ALIGN=\"LEFT\" CLASS=\"resultado\">"--\>"</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">"    "</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">"    "</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">"    "</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">"    "</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">"    "</TD>"
#    echo "</TABLE>"
#    echo "<HR>"
#    echo "<TABLE WIDTH=800>"
 fi
# datos tabulares
 echo $linea | awk '{ print  "<TR><TD ALIGN=\"LEFT\" CLASS=\"resultado\">" $1 "</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">" $2 "</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">" $3 "</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">" $4 "</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">" $5 "</TD><TD ALIGN=\"LEFT\" CLASS=\"resultado\">" $6 "</TD>" }'
# observaciones que es un dato variable
# echo $linea | awk -F"->" '{ print  "<TD ALIGN=\"LEFT\" CLASS=\"resultado\">"$2"</TD></TR>"}'
 obs=" "
 cnt=0
 for i in $linea
 do
     if [ $cnt -gt 5 ]; then
        obs="$obs $i"
     fi
     cnt=`expr $cnt + 1`
 done
 echo "<TD ALIGN=\"LEFT\" CLASS=\"resultado\">"$obs $n"</TD></TR>"
 dia_ant=$dia
done
echo "</TABLE>"
echo "</BODY>"
echo "</HTML>"
}

if [ $# != 3 ]; then
   echo "Uso : consola2html <archorigen> <lineas> <archdestino>"
   exit 1
else
   if [ ! -f "$1" ] ; then
      echo "Error : archivo origen no existe"
      exit 1
   else
      # falta verificar que $2 sea numerico para que no cancele el tail -$2
      consola2html $1 $2 > $3
   fi
fi


