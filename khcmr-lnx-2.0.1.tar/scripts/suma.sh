TOTAL=0
for i in $*; do
    TOTAL=`expr $TOTAL + $i`
done
echo $TOTAL

