################################################################
## Uso : verif_ejec_ctrl_disponibilidad.sh <nomarchivo> <fechainic> <fechafin> <n>
## Descripció Verifica que el log pasado como parametro tenga un registro cada n minutos, entre las fechas 
##               especificadas
##               Devuelve algo del estilo:
##			Fecha :  2006-02-20
##			  Registrado fuera de frecuencia , revisar el log:  15:50:06
##			  Registrado fuera de frecuencia , revisar el log:  16:05:04
##			  Registrado fuera de frecuencia , revisar el log:  19:40:05
##			Fecha :  2006-02-21
##			  Registrado fuera de frecuencia , revisar el log:  00:00:17
##
##               Con esto podemos controlar que el script de control de disponibilidades este corriendo cada n minutos

## Autor: A.Cristiani
## Fecha: 2/2/2006
################################################################
## Modificaciones
####
## Autor:
## Fecha:
## Descr:
####
################################################################
#! /bin/sh

. ${HOME}/.profile

if [ $# != 4 ]; then
   echo "Error: cantidad de parametros incorrecta"
   echo "Uso  : " $0 " <nomarchivo> <fechainic> <fechafin> <n>"
   exit -1
fi

ARCH=$1
FEC1=$2
FEC2=$3
FREC=$4
TMP=/tmp/verif_ejec_ctrl_disponibilidad.tmp

# cargo funciones auxiliares de fecha y hora
. ./date_funcs.sh

# en verif_ejec_ctrl_disponibilidad.tmp queda un archivo con formato "fecha hora" con todos los registros
# entre 2 fechas dadas.

awk '{ fec=$1; hora=$2; ret="\n"; if (fec >= pa_fec1 && fec <= pa_fec2)
                                {
                                printf "%10.10s ", fec;
                                printf "%8.8s\n", hora;
#				printf "%10.10s", ret ;
                                }
             }' pa_fec1=$FEC1 pa_fec2=$FEC2 $ARCH  > ${TMP}

# aca muestra fecha y para esa fecha todas las hs en que hubo diferencia de mas N minutos, no repite la fecha

fecha_ant=1900-01-01
hora_ant=00:00:00
cut -f1 $TMP | while read linea; do
    fecha=`echo $linea | awk '{print $1}'`
    hora=`echo $linea | awk '{print $2}'`
    if [ $fecha_ant != $fecha ]; then
       echo "Fecha : " $fecha
    fi

    DIF=`resto_horas $hora $hora_ant`
    # para los casos de cambio de fecha, la hora nueva queda 00:00 y la hora vieja 23:55
    # 86400=24hs*60min*60segs. En este caso DIF es negativo y deberia rondar las 24 hs menos 5 min
    if [ $DIF -lt 0 ] && [ $((86400+$DIF)) -gt $((60*$FREC)) ]; then
       echo "Registrado fuera de frecuencia , revisar el log: " $hora
    fi
    if [ $DIF -gt $((60*$FREC)) ]; then
       echo "Registrado fuera de frecuencia , revisar el log: " $hora
    fi

    hora_ant=$hora
    fecha_ant=$fecha
done

exit


